export default {
  expo: {
    name: "Challenge-Mobile",
    slug: "challenge-mobile",
    extra: {
      EXPO_PUBLIC_FIREBASE_API_KEY: "AIzaSyCrMJ9ojWi6IMEHwBFQTfxeCOcWdoAfQh0",
      EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN: "xp-health-challenge.firebaseapp.com",
      EXPO_PUBLIC_FIREBASE_PROJECT_ID: "xp-health-challenge",
      EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET: "xp-health-challenge.firebasestorage.app",
      EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID: "354744479783",
      EXPO_PUBLIC_FIREBASE_APP_ID: "1:354744479783:web:28850ece2717c3725ede02",
      EXPO_PUBLIC_FIREBASE_MEASUREMENT_ID: "G-ECJ09NDZG1",
    },
  },
};

